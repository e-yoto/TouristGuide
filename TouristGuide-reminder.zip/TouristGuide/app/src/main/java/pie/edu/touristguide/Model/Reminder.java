package pie.edu.touristguide.Model;

public class Reminder {

    private String title;
    private String time;
    private String location;
    private String weather;

    public Reminder(String title, String time, String location, String weather) {
        this.title = title;
        this.time = time;
        this.location = location;
        this.weather = weather;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getWeather() {
        return weather;
    }

    public void setWeather(String weather) {
        this.weather = weather;
    }

    @Override
    public String toString() {
        return "Reminder{" +
                "title='" + title + '\'' +
                ", time='" + time + '\'' +
                ", location='" + location + '\'' +
                ", weather='" + weather + '\'' +
                '}';
    }
}
