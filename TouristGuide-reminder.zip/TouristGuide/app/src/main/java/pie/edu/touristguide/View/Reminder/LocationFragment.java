package pie.edu.touristguide.View.Reminder;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import pie.edu.touristguide.Model.Reminder;
import pie.edu.touristguide.R;
import pie.edu.touristguide.View.HomeFragment;

/**
 * A simple {@link Fragment} subclass.
 */
public class LocationFragment extends Fragment implements View.OnClickListener {

    private List<Reminder> reminders;
    private ReminderRvAdapter adapter;

    public LocationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.reminder_location, container, false);

        FloatingActionButton addFAB = rootView.findViewById(R.id.fab_add);
        addFAB.setOnClickListener(this);

        reminders = new ArrayList<>();
        reminders.add(new Reminder("Buy bath bomb!", "6:00am-11:30pm", "Cosmetic Shop", ""));
        reminders.add(new Reminder("Bring Cactus indoor", "6:00am-11:00pm", "Home", "Stormy"));
        reminders.add(new Reminder("Do android homework", "", "Home", ""));
        reminders.add(new Reminder("Buy bath bomb!", "6:00am-11:30pm", "Cosmetic Shop", ""));
        reminders.add(new Reminder("Bring Cactus indoor", "6:00am-11:00pm", "Home", "Stormy"));
        reminders.add(new Reminder("Do android homework", "", "Home", ""));
        reminders.add(new Reminder("Buy bath bomb!", "6:00am-11:30pm", "Cosmetic Shop", ""));
        reminders.add(new Reminder("Bring Cactus indoor", "6:00am-11:00pm", "Home", "Stormy"));
        reminders.add(new Reminder("Do android homework", "", "Home", ""));
        reminders.add(new Reminder("Buy bath bomb!", "6:00am-11:30pm", "Cosmetic Shop", ""));
        reminders.add(new Reminder("Bring Cactus indoor", "6:00am-11:00pm", "Home", "Stormy"));
        reminders.add(new Reminder("Do android homework", "", "Home", ""));
        reminders.add(new Reminder("Buy bath bomb!", "6:00am-11:30pm", "Cosmetic Shop", ""));
        reminders.add(new Reminder("Bring Cactus indoor", "6:00am-11:00pm", "Home", "Stormy"));
        reminders.add(new Reminder("Do android homework", "", "Home", ""));

        RecyclerView recyclerView = rootView.findViewById(R.id.rv_reminders);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new ReminderRvAdapter(reminders, getActivity());
        recyclerView.setAdapter(adapter);

        return rootView;


    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        Fragment fragment = new HomeFragment();

        switch (id){
            case R.id.fab_add:
                fragment = new AddFragment();
                break;
        }

        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.enter_from_left, R.anim.exit_to_right,
                R.anim.enter_from_right, R.anim.exit_to_left);
        transaction.replace(R.id.fragment_holder, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
