package pie.edu.touristguide.View.Reminder;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import pie.edu.touristguide.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class AddFragment extends Fragment{


    public AddFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.reminder_add, container, false);


        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        setToolBar(R.id.save_data_toolbar);
    }

    @Override
    public void onPause() {
        super.onPause();
        setToolBar(R.id.main_toolbar);
    }

    public void setToolBar(int toolbarId){
        DrawerLayout drawerLayout = getActivity().findViewById(R.id.drawer_layout);
        switch (toolbarId){
            case R.id.main_toolbar:
                drawerLayout.findViewById(R.id.main_toolbar).setVisibility(View.VISIBLE);
                drawerLayout.findViewById(R.id.save_data_toolbar).setVisibility(View.GONE);
                break;
            case R.id.save_data_toolbar:
                drawerLayout.findViewById(R.id.main_toolbar).setVisibility(View.GONE);
                drawerLayout.findViewById(R.id.save_data_toolbar).setVisibility(View.VISIBLE);
                break;
        }
    }


}
