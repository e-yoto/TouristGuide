package pie.edu.touristguide.View;

import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import pie.edu.touristguide.R;
import pie.edu.touristguide.View.Reminder.LocationFragment;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    private DrawerLayout navDrawer;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);

        navDrawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, navDrawer, toolbar,
                R.string.open_drawer, R.string.close_drawer);

        navDrawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        if(savedInstanceState == null){
            Fragment fragment = new HomeFragment();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.setCustomAnimations(R.anim.enter_from_left, R.anim.exit_to_right,
                    R.anim.enter_from_right, R.anim.exit_to_left);
            transaction.replace(R.id.fragment_holder, fragment);
            transaction.addToBackStack(null);
            transaction.commit();
            navigationView.setCheckedItem(R.id.home);
        }

        ImageView addIV = findViewById(R.id.iv_add);
        addIV.setOnClickListener(this);

        ImageView cancelIV = findViewById(R.id.iv_cancel);
        cancelIV.setOnClickListener(this);


    }


    @Override
    public void onBackPressed() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        if(count == 0){
            super.onBackPressed();
        }else {
            getSupportFragmentManager().popBackStack();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        Fragment fragment = new HomeFragment();
        switch (menuItem.getItemId()){
            case R.id.language_learning:
                fragment = new TranslationMenuFragment();
                break;
            case R.id.currency_conversion:
                fragment = new CurrencyConversionFragment();
                break;
            case R.id.weather:
                fragment = new WeatherFragment();
                break;
            case R.id.conditional_reminder:
                fragment = new LocationFragment();
                break;


        }

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.enter_from_left, R.anim.exit_to_right,
                R.anim.enter_from_right, R.anim.exit_to_left);
        transaction.replace(R.id.fragment_holder, fragment);
        transaction.addToBackStack(null);
        transaction.commit();

        navDrawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void openTranslations(View view) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.enter_from_left, R.anim.exit_to_right,
                R.anim.enter_from_right, R.anim.exit_to_left);
        transaction.replace(R.id.fragment_holder, new TranslationFragment());
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.iv_cancel:
                Toast.makeText(this, "cancel", Toast.LENGTH_LONG).show();
                break;
            case R.id.iv_add:
                Toast.makeText(this, "data saved", Toast.LENGTH_LONG).show();
                break;
        }
    }
}
