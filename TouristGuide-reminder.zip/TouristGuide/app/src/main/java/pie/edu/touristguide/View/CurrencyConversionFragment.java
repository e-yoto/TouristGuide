package pie.edu.touristguide.View;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.DecimalFormat;

import pie.edu.touristguide.Controller.ConverterClass;
import pie.edu.touristguide.R;

public class CurrencyConversionFragment extends Fragment implements AdapterView.OnItemSelectedListener{
    String selectedCurrency;
    String selectedConvertCurrency;
    View rootView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.currency_conversion_layout, container, false);
        Button btnConvert = (Button) rootView.findViewById(R.id.btnConvert);
        Spinner currentCurrecySpinner = (Spinner) rootView.findViewById(R.id.currentCurrencySpinner);
        Spinner convertedCurrecySpinner = (Spinner) rootView.findViewById(R.id.convertedCurrencySpinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(), R.array.currencies, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);

        currentCurrecySpinner.setAdapter(adapter);
        convertedCurrecySpinner.setAdapter(adapter);

        currentCurrecySpinner.setOnItemSelectedListener(this);
        convertedCurrecySpinner.setOnItemSelectedListener(this);

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText currencyInput = (EditText) rootView.findViewById(R.id.currentCurrencyInput);
                TextView conversionRatesView = (TextView) rootView.findViewById(R.id.conversion_rates);
                TextView convertedResultView = (TextView) rootView.findViewById(R.id.converted_currency_result);
                String currentCurrencyInit = null; double currentCurrencyRate = 0;
                String convertCurrencyInit = null; double convertCurrencyRate = 0;

                try{
                    Double amountInput = Double.parseDouble(currencyInput.getText().toString());


                    //DUMMY DATA
                    //Switch Cases and calculations will be implemented in the Controller
                    switch (selectedCurrency){
                        case "Canadian Dollar":
                            currentCurrencyInit = "CAD";
                            currentCurrencyRate = 1.5118;
                            break;

                        case "American Dollar":
                            currentCurrencyInit = "USD";
                            convertCurrencyRate = 1.1308;
                            break;

                        case "European Euro":
                            currentCurrencyInit = "EUR";
                            currentCurrencyRate = 1;
                    }

                    switch (selectedConvertCurrency){
                        case "Canadian Dollar":
                            convertCurrencyInit = "CAD";
                            convertCurrencyRate = 1.5118;
                            break;

                        case "American Dollar":
                            convertCurrencyInit = "USD";
                            convertCurrencyRate = 1.1308;
                            break;

                        case "European Euro":
                            convertCurrencyInit = "EUR";
                            convertCurrencyRate = 1;
                    }

                    DecimalFormat format = new DecimalFormat("#.00");

                    double convertedAmount = (amountInput * convertCurrencyRate)/currentCurrencyRate;
                    convertedResultView.setText(format.format(convertedAmount));

                    double convertedRate = (1 * convertCurrencyRate)/currentCurrencyRate;
                    conversionRatesView.setText("1 " + currentCurrencyInit + " is equal to " + format.format(convertedRate) + " " + convertCurrencyInit);
                }
                catch (Exception e){
                    Toast.makeText(getContext(), "Please fill out input correctly", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        });

        return rootView;
    }

    /**
     * Trying to change the result as the user enters a digit.
     * @return
     */
//    @Override
//    public boolean dispatchKeyEvent(KeyEvent event) {
//
//        return super.dispatchKeyEvent(event);
//    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (parent.getId() == R.id.currentCurrencySpinner){
            selectedCurrency = parent.getItemAtPosition(position).toString();
        }
        else if (parent.getId() == R.id.convertedCurrencySpinner){
            selectedConvertCurrency = parent.getItemAtPosition(position).toString();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }
}
