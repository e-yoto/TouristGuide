package pie.edu.touristguide.Controller;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ConverterClass {
    String currentCurrency;
    String convertCurrency;
    JSONObject json;

    public ConverterClass(){
        URL url = null;
        try {
            url = new URL("https://api.exchangeratesapi.io/latest");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            // 2. Open InputStream to connection
            conn.connect();
            InputStream in = conn.getInputStream();
            // 3. Download and decode the string response using builder
            StringBuilder stringBuilder = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            System.out.println(stringBuilder);

            json = new JSONObject(stringBuilder.toString());
            //System.out.println("CAD rates:" + json.getJSONObject("rates").get("CAD"));
            //System.out.println("USD rates:" + json.getJSONObject("rates").get("USD"));

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public /*double*/ void convertCurrency(Double amount, String currentCurrency, String convertCurrency){
        this.currentCurrency = currentCurrency;
        this.convertCurrency = convertCurrency;

        try {
            double currentRate = (Double) json.getJSONObject("rates").get(currentCurrency);
            double convertRate = (Double) json.getJSONObject("rates").get(convertCurrency);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        //Convert amount to Euro First
        //(currentAmount * euroRate) / currentRate

    }
}
