package pie.edu.touristguide.View.Reminder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import pie.edu.touristguide.Model.Reminder;
import pie.edu.touristguide.R;

public class ReminderRvAdapter extends RecyclerView.Adapter<ReminderRvAdapter.ViewHolder> {

    private List<Reminder> mReminders;
    private LayoutInflater mInflator;
    private Context context;

    public ReminderRvAdapter(List<Reminder> reminders, Context context){
        this.mReminders = reminders;
        this.context = context;
        mInflator = LayoutInflater.from(context);
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = mInflator.inflate(R.layout.reminder_rv_row, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Reminder reminder = mReminders.get(i);
        viewHolder.titleTv.setText(reminder.getTitle());
        viewHolder.timeTv.setText(reminder.getTime());
        viewHolder.locationTv.setText(reminder.getLocation());
        viewHolder.weatherTv.setText(reminder.getWeather());
    }

    @Override
    public int getItemCount() {
        return mReminders.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView titleTv;
        TextView timeTv;
        TextView locationTv;
        TextView weatherTv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTv = itemView.findViewById(R.id.tv_title);
            timeTv = itemView.findViewById(R.id.tv_time);
            locationTv = itemView.findViewById(R.id.tv_location);
            weatherTv = itemView.findViewById(R.id.tv_weather);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = this.getAdapterPosition();
            Toast.makeText(context, mReminders.get(position).toString(), Toast.LENGTH_LONG).show();
        }
    }

}
