package pie.edu.touristguide.View;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.util.ArrayList;

import pie.edu.touristguide.Model.TranslatedSentence;
import pie.edu.touristguide.R;

public class TranslationFragment extends Fragment {
// https://stackoverflow.com/questions/40584424/simple-android-recyclerview-example
ArrayList<TranslatedSentence> sentences;
    private static String TAG = "TranslationActivity123";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.translation_layout, container, false);
        //initialize sentences
        sentences = TranslatedSentence.createSentencesList(10);
        Log.v(TAG, sentences.size() + " size");
        for(TranslatedSentence t : sentences)
        {
            Log.v("sentences",t.toString());
        }

        //get recyclerview
        RecyclerView rvSentences = (RecyclerView) rootView.findViewById(R.id.rvTranslations);

        //set layout manager to position items
        rvSentences.setLayoutManager(new LinearLayoutManager(getActivity()));

        //create adapter
        TranslationRVAdapter adapter = new TranslationRVAdapter(getActivity(), sentences);


        //attach adapter
        rvSentences.setAdapter(adapter);

        return rootView;
    }


}
